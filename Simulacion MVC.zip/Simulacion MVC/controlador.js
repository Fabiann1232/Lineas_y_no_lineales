import { Salon } from "./modelo.js";

function obtenerSalonAleatorio() {
    return salones[Math.floor(Math.random() * salones.length)];
  }
  
  function setAspiradoraPosition(aspiradoraElement, salonElement) {
    const rect = salonElement.getBoundingClientRect();
    aspiradoraElement.style.left = rect.left + 'px';
    aspiradoraElement.style.top = rect.top + 'px';
  }
  
  async function limpiarSalon(salon) {
    if (!salon.limpiado) {
      if (!salon.ocupado) {
        mensaje.innerHTML = "Limpiando salón " + salon.id;
        salon.setImage("./images/salon-sucio.png");
        const aspiradoraElement = document.createElement("img"); // Cambia "div" por "img"
        aspiradoraElement.classList.add("aspiradora");
        aspiradoraElement.src = "./images/aspiradora.png"; // Añade esta línea para establecer la imagen de la aspiradora
        setAspiradoraPosition(aspiradoraElement, salon.element);
        salon.element.appendChild(aspiradoraElement);
        await sleep(2000);
        salon.limpiado = true;
        salon.setImage("./images/salon-limpio.png");
        salon.element.removeChild(aspiradoraElement);
        mensaje.innerHTML = "Limpieza exitosa salón " + salon.id;
        await sleep(2000);
        return true;
      } else {
        mensaje.innerHTML = "Salón " + salon.id + " ocupado";
        salon.setImage("./images/salon-ocupado.png");
        await sleep(2000);
        salon.ocupado = false;
      }
    } else {
      mensaje.innerHTML = "Salón " + salon.id + " ya limpiado";
      await sleep(2000);
    }
    return false;
  }
  
  
  function crearSalones() {
    const salones = [];
    const labels = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
    for (let i = 0; i < 8; i++) {
      const salon = new Salon(labels[i], Math.random() < 0.5);
      salones.push(salon);
      const salonElement = document.createElement("div");
      salonElement.classList.add("salon");
      salonElement.textContent = labels[i];
      salon.element = salonElement;
  
      const imageElement = document.createElement("img");
      imageElement.classList.add("background");
      imageElement.src = salon.ocupado ? "./images/salon-ocupado.png" : "./images/salon-sucio.png"; // Modifica las rutas aquí
      salon.imageElement = imageElement;
      salonElement.appendChild(imageElement);
  
      if (i < 4) {
        document.getElementById("fila1").appendChild(salonElement);
      } else {
        document.getElementById("fila2").appendChild(salonElement);
      }
    }
    return salones;
  }
  
  
  // Agrega esta función sleep al archivo
  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  
  // Agrega estos eventos y elementos al final del archivo
  const mensaje = document.getElementById("message");
  const botonIniciar = document.getElementById("startButton");
  const botonFinalizar = document.getElementById("stopButton");
  
  botonIniciar.addEventListener("click", () => {
    reiniciarSalones();
    iniciarSimulacion();
  });
  
  botonFinalizar.addEventListener("click", () => {
    location.reload();
  });
  
  const salones = crearSalones();
  
  function reiniciarSalones() {
    for (let salon of salones) {
      salon.limpiado = false;
      salon.ocupado = Math.random() < 0.5;
      salon.setImage(salon.ocupado ? "./images/salon-ocupado.png" : "./images/salon-sucio.png");
    }
  }
  let ciclos = 0;
  let salonesLimpios = 0;
  
  async function iniciarSimulacion() {
    while (ciclos < 3) {
      for (let salon of salones) {
        if (salon.ocupado) {
          mensaje.innerHTML = "Salón " + salon.id + " ocupado";
          salon.setImage("./images/salon-ocupado.png");
          await sleep(2000);
          salon.ocupado = false;
          salon.setImage("./images/salon-sucio.png");
        } else if (!salon.limpiado) {
          const limpiado = await limpiarSalon(salon);
          if (limpiado) {
            salon.limpiado = true;
          }
        }
      }
  
      await sleep(1000);
  
      if (salones.every(salon => !salon.ocupado && salon.limpiado)) {
        ciclos++;
        mensaje.innerHTML = "Todos los salones han sido limpiados.";
        if (ciclos < 3) {
          mensaje.innerHTML += " Descanso de 5 horas";
          await sleep(5000);
          reiniciarSalones();
          mensaje.innerHTML = "";
        }
      }
    }
  }