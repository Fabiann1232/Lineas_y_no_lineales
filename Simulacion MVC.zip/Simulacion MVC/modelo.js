export class Salon {
    constructor(id, ocupado) {
      this.id = id;
      this.ocupado = ocupado;
      this.limpiado = false;
      this.element = null;
      this.imageElement = null;
    }
  
    setImage(src) {
      this.imageElement.src = src;
    }
  }
  